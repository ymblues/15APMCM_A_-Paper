import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize
import PyKDL as kdl

plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# --------------------------
# 1. 初始化系统参数（基于Unitree G1技术规格）
# --------------------------
# 运动参数
rotation_angle_body = np.radians(45)  # 身体左转角度（45°）
circle_radius_arm = 0.3  # 双臂圆周运动半径（m）
circle_period = 4.0  # 圆周运动周期（s）
time_range = np.linspace(0, circle_period, 1000)  # 时间序列（0-4s）

# 质量参数（kg）
mass_body = 30.0  # 躯干质量
mass_arm = 1.2  # 单臂质量
mass_leg = 3.5  # 单腿质量
total_mass = mass_body + 2 * mass_arm + 2 * mass_leg  # 总质量

# 几何参数（m）
length_upper_arm = 0.3  # 上臂长度
length_lower_arm = 0.3  # 前臂长度
support_boundary = 0.05  # 重心左右方向支撑边界（m）
compensation_coeff = 0.5  # 腿部补偿系数（rad/m）


# --------------------------
# 2. 基础动作建模（身体旋转+双臂圆周运动）
# --------------------------
def body_rotation_angle(t):
    """身体左转角度模型（匀角速度）"""
    angular_velocity = rotation_angle_body / circle_period
    return angular_velocity * t


def arm_joint_angles(t):
    """双臂关节角度模型（反向圆周运动）"""
    angular_frequency = 2 * np.pi / circle_period
    # 左臂关节角度（俯仰+外展）
    left_hip_pitch = circle_radius_arm * np.sin(angular_frequency * t)
    left_hip_abduction = circle_radius_arm * np.cos(angular_frequency * t)
    # 右臂关节角度（与左臂反向）
    right_hip_pitch = -left_hip_pitch
    right_hip_abduction = -left_hip_abduction
    return left_hip_pitch, left_hip_abduction, right_hip_pitch, right_hip_abduction


# 生成基础动作数据
body_angles = np.array([body_rotation_angle(t) for t in time_range])
left_pitch, left_abduction, right_pitch, right_abduction = zip(*[arm_joint_angles(t) for t in time_range])

print("=" * 50)
print("步骤2：基础动作建模结果")
print("=" * 50)
print(f"身体旋转角速度：{rotation_angle_body / circle_period:.3f} rad/s")
print(f"双臂圆周运动角速度：{2 * np.pi / circle_period:.3f} rad/s")
print(f"左臂最大俯仰角：{np.max(np.degrees(left_pitch)):.1f} °")
print(f"右臂最大外展角：{np.max(np.degrees(right_abduction)):.1f} °")


# --------------------------
# 3. 重心计算与腿部补偿建模
# --------------------------
def calculate_center_of_gravity(t):
    """计算时刻t的重心坐标（x,y,z）"""
    # 身体旋转矩阵（绕z轴）
    body_angle = body_rotation_angle(t)
    rot_z = np.array([[np.cos(body_angle), -np.sin(body_angle), 0],
                      [np.sin(body_angle), np.cos(body_angle), 0],
                      [0, 0, 1]])

    # 双臂端点位置（相对肩关节）
    left_pitch_t, left_abd_t, right_pitch_t, right_abd_t = arm_joint_angles(t)
    # 左臂位置（躯干坐标系）
    left_arm_pos = np.array([length_upper_arm * np.cos(left_pitch_t) * np.sin(left_abd_t),
                             length_upper_arm * np.sin(left_pitch_t),
                             length_upper_arm * np.cos(left_pitch_t) * np.cos(left_abd_t)])
    # 右臂位置（躯干坐标系）
    right_arm_pos = np.array([length_upper_arm * np.cos(right_pitch_t) * np.sin(right_abd_t),
                              length_upper_arm * np.sin(right_pitch_t),
                              length_upper_arm * np.cos(right_pitch_t) * np.cos(right_abd_t)])

    # 躯干中心位置（原点）
    body_pos = np.array([0, 0, 0.8])  # 躯干中心z坐标（假设）

    # 重心坐标（质量加权，旋转到世界坐标系）
    cog_body = mass_body * body_pos
    cog_left_arm = mass_arm * (body_pos + np.dot(rot_z, left_arm_pos))
    cog_right_arm = mass_arm * (body_pos + np.dot(rot_z, right_arm_pos))
    # 腿部初始位置（对称分布）
    leg_pos_left = np.array([0, 0.1, 0.4])
    leg_pos_right = np.array([0, -0.1, 0.4])
    cog_left_leg = mass_leg * np.dot(rot_z, leg_pos_left)
    cog_right_leg = mass_leg * np.dot(rot_z, leg_pos_right)

    cog_total = (cog_body + cog_left_arm + cog_right_arm + cog_left_leg + cog_right_leg) / total_mass
    return cog_total


def leg_compensation_angle(t):
    """基于重心偏移的腿部髋关节外展补偿角度"""
    cog = calculate_center_of_gravity(t)
    y_offset = cog[1]  # 左右方向重心偏移
    # 补偿角度（限制在安全范围）
    compensation_angle = compensation_coeff * y_offset
    return np.clip(compensation_angle, -np.radians(5), np.radians(5))


# 生成重心与腿部补偿数据
cog_data = np.array([calculate_center_of_gravity(t) for t in time_range])
leg_compensation_angles = np.array([leg_compensation_angle(t) for t in time_range])

print("\n" + "=" * 50)
print("步骤3：重心计算与腿部补偿结果")
print("=" * 50)
print(f"重心x方向范围：{np.min(cog_data[:, 0]):.3f} - {np.max(cog_data[:, 0]):.3f} m")
print(f"重心y方向范围：{np.min(cog_data[:, 1]):.3f} - {np.max(cog_data[:, 1]):.3f} m")
print(f"重心z方向范围：{np.min(cog_data[:, 2]):.3f} - {np.max(cog_data[:, 2]):.3f} m")
print(f"腿部最大补偿角度：{np.max(np.degrees(leg_compensation_angles)):.1f} °")
print(f"重心是否在支撑面内：{'是' if np.max(np.abs(cog_data[:, 1])) <= support_boundary else '否'}")


# --------------------------
# 4. 雅可比矩阵协同验证
# --------------------------
def create_arm_kinematic_model():
    """创建单臂运动学模型（3自由度）"""
    chain = kdl.Chain()
    # 肩关节俯仰（z轴）
    joint1 = kdl.Joint(kdl.Joint.RotZ)
    frame1 = kdl.Frame(kdl.Rotation::Rz(0), kdl.Vector(0, 0, 0))
    chain.addSegment(kdl.Segment(joint1, frame1))
    # 肩关节外展（y轴）
    joint2 = kdl.Joint(kdl.Joint.RotY)
    frame2 = kdl.Frame(kdl.Rotation::Ry(0), kdl.Vector(0, 0, length_upper_arm))
    chain.addSegment(kdl.Segment(joint2, frame2))
    # 肘关节屈伸（z轴）
    joint3 = kdl.Joint(kdl.Joint.RotZ)
    frame3 = kdl.Frame(kdl.Rotation::Rz(0), kdl.Vector(length_lower_arm, 0, 0))
    chain.addSegment(kdl.Segment(joint3, frame3))
    return chain


def calculate_jacobian(chain, q):
    """计算雅可比矩阵"""
    jacobian = kdl.Jacobian(chain.getNrOfJoints())
    jnt_array = kdl.JntArray(chain.getNrOfJoints())
    for i in range(chain.getNrOfJoints()):
        jnt_array[i] = q[i]
    chain.Jacobian(jnt_array, jacobian)
    return np.array(jacobian)


# 协同验证（双臂速度反向一致性）
arm_chain = create_arm_kinematic_model()
velocity_consistency = []
for t in time_range[:100]:  # 抽样验证
    left_pitch_t, left_abd_t, _, _ = arm_joint_angles(t)
    # 左臂关节角度
    q_left = np.array([left_pitch_t, left_abd_t, 0])
    # 右臂关节角度
    q_right = np.array([-left_pitch_t, -left_abd_t, 0])
    # 计算雅可比矩阵
    jac_left = calculate_jacobian(arm_chain, q_left)
    jac_right = calculate_jacobian(arm_chain, q_right)
    # 端点速度（理论反向）
    vel_left = jac_left @ np.array([2 * np.pi / circle_period, 2 * np.pi / circle_period, 0])
    vel_right = jac_right @ np.array([-2 * np.pi / circle_period, -2 * np.pi / circle_period, 0])
    # 速度一致性（相对误差）
    consistency = np.linalg.norm(vel_left + vel_right) / np.linalg.norm(vel_left)
    velocity_consistency.append(consistency)

print("\n" + "=" * 50)
print("步骤4：雅可比协同验证结果")
print("=" * 50)
print(f"双臂速度反向一致性平均误差：{np.mean(velocity_consistency) * 100:.2f} %")
print(f"最大速度一致性误差：{np.max(velocity_consistency) * 100:.2f} %")
print(f"协同控制精度：{'优秀' if np.mean(velocity_consistency) < 0.05 else '良好'}")

# --------------------------
# 5. 结果可视化
# --------------------------
fig = plt.figure(figsize=(18, 12))

# 5.1 身体与双臂关节角度曲线
ax1 = plt.subplot(2, 3, 1)
ax1.plot(time_range, np.degrees(body_angles), color='#264653', linewidth=2.5, label='身体左转角度')
ax1.set_xlabel('Time（s）', fontsize=11)
ax1.set_ylabel('Angle（°）', fontsize=11)
ax1.set_title('Body rotation angle-time curve', fontsize=13, fontweight='bold')
ax1.legend(fontsize=10)
ax1.grid(True, alpha=0.3)

ax2 = plt.subplot(2, 3, 2)
ax2.plot(time_range, np.degrees(left_pitch), color='#2A9D8F', linewidth=2, label='左臂俯仰角')
ax2.plot(time_range, np.degrees(left_abduction), color='#E9C46A', linewidth=2, label='左臂外展角')
ax2.set_xlabel('Time（s）', fontsize=11)
ax2.set_ylabel('Angle（°）', fontsize=11)
ax2.set_title('Left arm joint angle-time curve', fontsize=13, fontweight='bold')
ax2.legend(fontsize=10)
ax2.grid(True, alpha=0.3)

ax3 = plt.subplot(2, 3, 3)
ax3.plot(time_range, np.degrees(right_pitch), color='#F4A261', linewidth=2, label='右臂俯仰角')
ax3.plot(time_range, np.degrees(right_abduction), color='#E76F51', linewidth=2, label='右臂外展角')
ax3.set_xlabel('Time（s）', fontsize=11)
ax3.set_ylabel('Angle（°）', fontsize=11)
ax3.set_title('Right arm joint angle-time curve', fontsize=13, fontweight='bold')
ax3.legend(fontsize=10)
ax3.grid(True, alpha=0.3)

# 5.2 重心坐标曲线
ax4 = plt.subplot(2, 3, 4)
ax4.plot(time_range, cog_data[:, 0], color='#9B5DE5', linewidth=2, label='x方向')
ax4.plot(time_range, cog_data[:, 1], color='#F15BB5', linewidth=2, label='y方向')
ax4.plot(time_range, cog_data[:, 2], color='#00BBF9', linewidth=2, label='z方向')
ax4.axhline(y=support_boundary, color='black', linestyle='--', alpha=0.5, label='支撑边界')
ax4.axhline(y=-support_boundary, color='black', linestyle='--', alpha=0.5)
ax4.set_xlabel('Time（s）', fontsize=11)
ax4.set_ylabel('barycentric coordinates（m）', fontsize=11)
ax4.set_title('Centroid coordinates-time curve', fontsize=13, fontweight='bold')
ax4.legend(fontsize=10)
ax4.grid(True, alpha=0.3)

# 5.3 腿部补偿角度曲线
ax5 = plt.subplot(2, 3, 5)
ax5.plot(time_range, np.degrees(leg_compensation_angles), color='#7400B8', linewidth=2.5)
ax5.axhline(y=5, color='red', linestyle='--', alpha=0.8, label='安全上限：5°')
ax5.axhline(y=-5, color='red', linestyle='--', alpha=0.8, label='安全下限：-5°')
ax5.set_xlabel('Time（s）', fontsize=11)
ax5.set_ylabel('Leg compensation angle（°）', fontsize=11)
ax5.set_title('Leg hip joint compensation angle-time curve', fontsize=13, fontweight='bold')
ax5.legend(fontsize=10)
ax5.grid(True, alpha=0.3)

# 5.4 双臂速度一致性曲线
ax6 = plt.subplot(2, 3, 6)
ax6.plot(np.linspace(0, circle_period, len(velocity_consistency)),
         np.array(velocity_consistency) * 100, color='#DC2626', linewidth=2.5)
ax6.axhline(y=5, color='green', linestyle='--', alpha=0.8, label='允许误差：5%')
ax6.set_xlabel('Time（s）', fontsize=11)
ax6.set_ylabel('Speed consistency error（%）', fontsize=11)
ax6.set_title('Dual-arm speed coordination consistency error', fontsize=13, fontweight='bold')
ax6.legend(fontsize=10)
ax6.grid(True, alpha=0.3)

plt.suptitle('Results of multi-joint cooperative motion planning for robots', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('problem3_collaborative_motion.png', dpi=300, bbox_inches='tight')
plt.show()

# --------------------------
# 6. 核心结果汇总
# --------------------------
print("\n" + "=" * 60)
print("问题3核心结果汇总")
print("=" * 60)
print(f"1. 身体旋转：45°（0-{circle_period}s匀速完成）")
print(f"2. 双臂运动：反向圆周运动（半径{circle_radius_arm}m，周期{circle_period}s）")
print(f"3. 重心控制：y方向最大偏移{np.max(np.abs(cog_data[:, 1])):.3f}m（≤{support_boundary}m）")
print(f"4. 腿部补偿：最大外展角度{np.max(np.degrees(leg_compensation_angles)):.1f}°（安全范围±5°）")
print(f"5. 协同精度：双臂速度反向一致性误差≤{np.max(velocity_consistency) * 100:.2f}%")
print("=" * 60)