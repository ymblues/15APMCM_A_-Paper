import numpy as np
import math

# --------------------------
# 步骤1：定义已知参数（适配调整后的初始姿态）
# --------------------------
l_upper = 169  # 上臂长度(mm)，初始沿z轴
l_lower = 169  # 小臂长度(mm)，初始沿x轴
alpha = math.pi / 3    # 向前抬角度：绕y轴负方向转60°（pi/3 rad）
beta = math.pi / 6     # 向左转角度：绕z轴正方向转30°（pi/6 rad）
m_arm = 1.2  # 左臂总质量(kg)
g = 9.8      # 重力加速度(m/s²)


# --------------------------
# 步骤2：计算初始状态下的关键坐标（调整点1：初始姿态）
# --------------------------
# 肘关节初始坐标（上臂沿z轴）
P_elbow_initial = np.array([0, 0, l_upper])  # (x, y, z) = (0, 0, 169) mm
# 端点初始坐标（小臂沿x轴，与上臂垂直）
P_end_initial = P_elbow_initial + np.array([l_lower, 0, 0])  # (169, 0, 169) mm
print("初始状态（未动作）：")
print(f"  肘关节坐标：{P_elbow_initial} mm")
print(f"  端点坐标：{P_end_initial} mm\n")


# --------------------------
# 步骤3：构建旋转矩阵（调整点2：转动顺序与轴）
# --------------------------
def rot_y_neg(angle):
    """绕y轴负方向旋转angle弧度的旋转矩阵（向前抬动作）"""
    c = math.cos(angle)
    s = math.sin(angle)
    return np.array([
        [c, 0, -s],
        [0, 1, 0],
        [s, 0, c]
    ])

def rot_z_pos(angle):
    """绕z轴正方向旋转angle弧度的旋转矩阵（向左转动作）"""
    c = math.cos(angle)
    s = math.sin(angle)
    return np.array([
        [c, -s, 0],
        [s, c, 0],
        [0, 0, 1]
    ])

# 总旋转矩阵：先绕y轴负方向转alpha（向前抬），再绕z轴正方向转beta（向左转）
R_lift = rot_y_neg(alpha)    # 向前抬的旋转矩阵
R_turn = rot_z_pos(beta)     # 向左转的旋转矩阵
R_total = np.dot(R_turn, R_lift)  # 矩阵乘法：先抬后转，顺序不可乱


# --------------------------
# 步骤4：计算最终端点坐标（调整点3：整体旋转初始坐标）
# --------------------------
# 初始坐标转为列向量（矩阵乘法要求），再乘总旋转矩阵
P_end_final = np.dot(R_total, P_end_initial.reshape(3, 1))  # 3×1列向量相乘
P_end_final = P_end_final.flatten()  # 转为1维数组，方便输出


# --------------------------
# 步骤5：电机安全验证（逻辑不变，适配新姿态的扭矩计算）
# --------------------------
# 1. 关节角度验证（转角度制）
alpha_deg = math.degrees(alpha)
beta_deg = math.degrees(beta)
angle_safe = (abs(alpha_deg) <= 90) and (abs(beta_deg) <= 45)  # 安全范围

# 2. 扭矩验证（计算手臂重心到肩关节的距离，适配垂直结构）
# 上臂重心：(0,0,l_upper/2)，小臂重心：(l_lower/2, 0, l_upper)
center_upper = np.array([0, 0, l_upper/2])
center_lower = np.array([l_lower/2, 0, l_upper])
# 总重心坐标（质量加权，假设上臂与小臂质量各占一半，m1=m2=0.6kg）
m1 = m2 = 0.6
center_total = (m1 * center_upper + m2 * center_lower) / (m1 + m2)
# 重心到肩关节的距离（旋转后距离不变，用初始距离计算）
dist_center = np.linalg.norm(center_total) / 1000  # 转米
# 扭矩=mg×dist_center×sin(抬起角度)，抬起角度仍是alpha=60°
torque = m_arm * g * dist_center * math.sin(alpha)
torque_safe = torque <= 5  # 额定扭矩≥5N·m


# --------------------------
# 步骤6：输出最终结果
# --------------------------
print("=" * 60)
print("问题1 求解结果（调整初始姿态：上臂沿z轴、小臂沿x轴，夹角90°）")
print("=" * 60)
print(f"1. 端点最终坐标（单位：mm）：")
print(f"   x = {P_end_final[0]:.1f} mm（向前）")
print(f"   y = {P_end_final[1]:.1f} mm（向左）")
print(f"   z = {P_end_final[2]:.1f} mm（向上）")
print(f"\n2. 动作对应的旋转矩阵：")
print(f"   - 向前抬60°（绕y轴负方向）：\n{R_lift.round(3)}")
print(f"   - 向左转30°（绕z轴正方向）：\n{R_turn.round(3)}")
print(f"   - 总旋转矩阵：\n{R_total.round(3)}")
print(f"\n3. 电机安全验证：")
print(f"   - 关节角度：绕y轴-{alpha_deg:.0f}°（安全±90°），绕z轴{beta_deg:.0f}°（安全±45°）")
print(f"   - 肩关节扭矩：{torque:.1f} N·m（额定≥5N·m）")
print(f"   - 整体安全状态：{'安全' if angle_safe and torque_safe else '不安全'}")
print("=" * 60)
