import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve

plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# --------------------------
# 1. 初始化基础参数（基于问题定义与工程经验）
# --------------------------
movement_distance = 10.0  # 运动距离（m）
average_speed = 2.0  # 平均速度（m/s）
# 关节最大角度（参考Unitree G1步态特性，单位：弧度）
max_hip_angle = np.radians(12)  # 髋关节最大偏转角度
max_knee_angle = np.radians(35)  # 膝关节最大偏转角度
max_ankle_angle = np.radians(8)  # 踝关节最大偏转角度
time_sampling = np.linspace(0, 6, 1000)  # 时间采样序列


# --------------------------
# 2. 求解总运动时间T（满足非匀速运动与平均速度约束）
# --------------------------
def velocity_function(t, a, b):
    """非匀速速度模型：v(t) = a*t - b*t²（满足t=0和t=T时速度为0）"""
    return a * t - b * t ** 2


def displacement_constraint(T, a, b):
    """位移约束方程：速度积分等于运动距离"""
    return 0.5 * a * T ** 2 - (b / 3) * T ** 3 - movement_distance


def calculate_total_time():
    """数值求解总运动时间T"""
    a_init = 2.5  # 初始加速度系数（m/s³）
    T_guess = movement_distance / average_speed  # 匀速运动时间初猜（5s）
    # 由平均速度约束推导b的初始关系
    b_init = (0.5 * a_init * T_guess - average_speed) * 3 / T_guess ** 2

    def equation(T):
        """待求解方程：满足位移约束的T"""
        b = (0.5 * a_init * T - average_speed) * 3 / T ** 2
        return displacement_constraint(T, a_init, b)

    T_solution = fsolve(equation, T_guess)[0]
    b_solution = (0.5 * a_init * T_solution - average_speed) * 3 / T_solution ** 2
    return T_solution, a_init, b_solution


# 执行总时间求解
T_total, a_coeff, b_coeff = calculate_total_time()
print("=" * 50)
print("步骤2：总运动时间求解结果")
print("=" * 50)
print(f"总运动时间 T = {T_total:.2f} s")
print(f"速度模型参数：a = {a_coeff:.3f} m/s³，b = {b_coeff:.3f} m/s⁴")

# 验证位移与平均速度
t_verify = np.linspace(0, T_total, 1000)
v_verify = velocity_function(t_verify, a_coeff, b_coeff)
actual_displacement = np.trapz(v_verify, t_verify)
actual_avg_speed = actual_displacement / T_total
print(f"验证位移：{actual_displacement:.2f} m（目标：10.00 m）")
print(f"验证平均速度：{actual_avg_speed:.2f} m/s（目标：2.00 m/s）")


# --------------------------
# 3. 构建关节角度-时间模型（三次多项式插值）
# --------------------------
def polynomial_coefficients(theta_max, T):
    """
    求解三次多项式系数：theta(t) = p*t³ + q*t² + r*t + s
    边界条件：t=0时theta=0、theta_dot=0；t=T时theta=0、theta_dot=0
    """
    s = 0.0  # 常数项（t=0时角度为0）
    r = 0.0  # 一次项系数（t=0时角速度为0）
    p = -2 * theta_max / T ** 3  # 三次项系数
    q = 3 * theta_max / T ** 2  # 二次项系数
    return p, q, r, s


# 计算各关节多项式系数
hip_coeffs = polynomial_coefficients(max_hip_angle, T_total)
knee_coeffs = polynomial_coefficients(max_knee_angle, T_total)
ankle_coeffs = polynomial_coefficients(max_ankle_angle, T_total)


def compute_joint_angle(t, coeffs):
    """基于多项式系数计算时刻t的关节角度"""
    p, q, r, s = coeffs
    return p * t ** 3 + q * t ** 2 + r * t + s


# 生成角度-时间数据
time_points = np.linspace(0, T_total, 1000)
hip_angles = compute_joint_angle(time_points, hip_coeffs)
knee_angles = compute_joint_angle(time_points, knee_coeffs)
ankle_angles = compute_joint_angle(time_points, ankle_coeffs)

print("\n" + "=" * 50)
print("步骤3：关节角度模型系数")
print("=" * 50)
print(f"髋关节系数（p, q, r, s）：{hip_coeffs}")
print(f"膝关节系数（p, q, r, s）：{knee_coeffs}")
print(f"踝关节系数（p, q, r, s）：{ankle_coeffs}")


# --------------------------
# 4. 求解膝关节角度变化率最大的时刻
# --------------------------
def joint_angular_velocity(t, coeffs):
    """计算关节角速度（角度对时间的一阶导数）"""
    p, q, r, _ = coeffs
    return 3 * p * t ** 2 + 2 * q * t + r


def find_max_velocity_moment(coeffs, T):
    """求解角速度最大的时刻（角加速度为0的解）"""
    p, q, _, _ = coeffs
    t_max = -q / (3 * p)  # 由角加速度=0推导
    # 边界校验：确保时刻在有效运动区间内
    if 0 <= t_max <= T:
        return t_max
    # 边界时刻角速度比较
    vel_start = joint_angular_velocity(0, coeffs)
    vel_end = joint_angular_velocity(T, coeffs)
    return 0 if vel_start > vel_end else T


# 执行求解
t_max_knee_vel = find_max_velocity_moment(knee_coeffs, T_total)
max_knee_angular_vel = joint_angular_velocity(t_max_knee_vel, knee_coeffs)

print("\n" + "=" * 50)
print("步骤4：膝关节角度变化率分析结果")
print("=" * 50)
print(f"角度变化率最大的时刻：t = {t_max_knee_vel:.2f} s")
print(f"最大角速度：{np.degrees(max_knee_angular_vel):.1f} °/s")
print(f"对应膝关节角度：{np.degrees(compute_joint_angle(t_max_knee_vel, knee_coeffs)):.1f} °")

# --------------------------
# 5. 结果可视化（学术图表规范）
# --------------------------
fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
fig.suptitle('问题2：机器人运动轨迹建模与时间规划结果', fontsize=16, fontweight='bold')

# 5.1 速度-时间曲线
ax1.plot(t_verify, v_verify, color='#2E86AB', linewidth=2.5,
         label=f'v(t) = {a_coeff:.3f}t - {b_coeff:.3f}t²')
ax1.axhline(y=average_speed, color='#A23B72', linestyle='--', alpha=0.8,
            label=f'平均速度：{average_speed} m/s')
ax1.set_xlabel('时间（s）', fontsize=12)
ax1.set_ylabel('速度（m/s）', fontsize=12)
ax1.set_title('速度-时间曲线', fontsize=14, fontweight='bold')
ax1.legend(fontsize=10)
ax1.grid(True, alpha=0.3)
ax1.set_xlim(0, T_total + 0.5)

# 5.2 关节角度-时间曲线
ax2.plot(time_points, np.degrees(hip_angles), color='#F18F01', linewidth=2,
         label=f'髋关节（最大：{np.degrees(max_hip_angle):.1f}°）')
ax2.plot(time_points, np.degrees(knee_angles), color='#C73E1D', linewidth=2,
         label=f'膝关节（最大：{np.degrees(max_knee_angle):.1f}°）')
ax2.plot(time_points, np.degrees(ankle_angles), color='#6A994E', linewidth=2,
         label=f'踝关节（最大：{np.degrees(max_ankle_angle):.1f}°）')
ax2.axvline(x=t_max_knee_vel, color='black', linestyle=':', alpha=0.8,
            label=f'膝关节最大速度时刻：t={t_max_knee_vel:.2f}s')
ax2.set_xlabel('时间（s）', fontsize=12)
ax2.set_ylabel('关节角度（°）', fontsize=12)
ax2.set_title('单腿关节角度-时间曲线', fontsize=14, fontweight='bold')
ax2.legend(fontsize=10)
ax2.grid(True, alpha=0.3)
ax2.set_xlim(0, T_total)

# 5.3 膝关节角速度-时间曲线
knee_velocities = joint_angular_velocity(time_points, knee_coeffs)
ax3.plot(time_points, np.degrees(knee_velocities), color='#4A4E69', linewidth=2.5)
ax3.axvline(x=t_max_knee_vel, color='#E0AFA0', linestyle='--', alpha=0.8,
            label=f'最大角速度：{np.degrees(max_knee_angular_vel):.1f} °/s')
ax3.axhline(y=0, color='black', linestyle='-', alpha=0.5)
ax3.set_xlabel('时间（s）', fontsize=12)
ax3.set_ylabel('膝关节角速度（°/s）', fontsize=12)
ax3.set_title('膝关节角速度-时间曲线', fontsize=14, fontweight='bold')
ax3.legend(fontsize=10)
ax3.grid(True, alpha=0.3)
ax3.set_xlim(0, T_total)

# 5.4 位移-时间曲线
displacement_curve = np.array([
    np.trapz(velocity_function(t_sub, a_coeff, b_coeff), np.linspace(0, t_sub, 100))
    for t_sub in time_points
])
ax4.plot(time_points, displacement_curve, color='#2B2D42', linewidth=2.5,
         label=f'累计位移：{displacement_curve[-1]:.2f} m')
ax4.axhline(y=movement_distance, color='#8D99AE', linestyle='--', alpha=0.8,
            label=f'目标距离：{movement_distance} m')
ax4.set_xlabel('时间（s）', fontsize=12)
ax4.set_ylabel('位移（m）', fontsize=12)
ax4.set_title('位移-时间曲线', fontsize=14, fontweight='bold')
ax4.legend(fontsize=10)
ax4.grid(True, alpha=0.3)
ax4.set_xlim(0, T_total)

plt.tight_layout()
plt.savefig('problem2_trajectory_analysis.png', dpi=300, bbox_inches='tight')
plt.show()

# --------------------------
# 6. 核心结果汇总
# --------------------------
print("\n" + "=" * 60)
print("问题2核心结果汇总")
print("=" * 60)
print(f"1. 总运动时间：T = {T_total:.2f} s")
print(f"2. 膝关节角度变化率最大时刻：t = {t_max_knee_vel:.2f} s")
print(f"3. 膝关节最大角速度：{np.degrees(max_knee_angular_vel):.1f} °/s")
print(f"4. 关节角度模型（θ(t) = pt³ + qt² + rt + s）：")
print(f"   - 髋关节：p={hip_coeffs[0]:.6f}, q={hip_coeffs[1]:.6f}, r={hip_coeffs[2]:.6f}, s={hip_coeffs[3]:.6f}")
print(f"   - 膝关节：p={knee_coeffs[0]:.6f}, q={knee_coeffs[1]:.6f}, r={knee_coeffs[2]:.6f}, s={knee_coeffs[3]:.6f}")
print(f"   - 踝关节：p={ankle_coeffs[0]:.6f}, q={ankle_coeffs[1]:.6f}, r={ankle_coeffs[2]:.6f}, s={ankle_coeffs[3]:.6f}")
print("=" * 60)